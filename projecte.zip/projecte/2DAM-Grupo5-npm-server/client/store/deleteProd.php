<?php
if ( isset ($_GET("id")) ) {
    $id = $_GET("id");
    $servername = "labs.inspedralbes.cat";
			$username = "a19angavimar_User";
			$password = "Projecto_grupo5";
			$database = "a19angavimar_Usuarios";

			$connection = new mysqli($servername, $username, $password, $database);

			if ($connection->connect_error) {
				die("Connection failed: " . $connection->connect_error);
			}

			$sql = "DELETE FROM Products WHERE codProd='$id'";
			$result = $connection->query($sql);

            if (!$result) {
				die("Invalid query: " . $connection->error);
			}

    header ("location: /store/modificarProducte.php");
} 
?>