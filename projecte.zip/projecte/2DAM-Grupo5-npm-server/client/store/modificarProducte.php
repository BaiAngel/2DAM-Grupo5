<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Producte</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">

</head>
<body style="margin: 50px;">
    <h1>Llista productes</h1>
    <a class="btn btn-primary" href="/store/createProd.php" role="button">Nou Client</a>
    <br>
    <table class="table">
        <thead>
			<tr>
				<th>CodProd</th>
				<th>Nom</th>
				<th>Preu</th>
				<th>codUsu</th>
			</tr>
		</thead>

        <tbody>
            <?php
            $servername = "labs.inspedralbes.cat";
			$username = "a19angavimar_User";
			$password = "Projecto_grupo5";
			$database = "a19angavimar_Usuarios";

			$connection = new mysqli($servername, $username, $password, $database);

			if ($connection->connect_error) {
				die("Connection failed: " . $connection->connect_error);
			}

			$sql = "SELECT * FROM Products";
			$result = $connection->query($sql);

            if (!$result) {
				die("Invalid query: " . $connection->error);
			}

            // read data of each row
			while($row = $result->fetch_assoc()) {
                echo "<tr>
                    <td>" . $row["codProd"] . "</td>
                    <td>" . $row["nom"] . "</td>
                    <td>" . $row["preu"] . "</td>
                    <td>" . $row["codUsu"] . "</td>
                    <td>
                        <a class='btn btn-primary btn-sm' href='/store/updateProd.php?id=$row[codProd]'>Update</a>
                        <a class='btn btn-danger btn-sm' href='/store/deleteProd.php?id=$row[codProd]'>Delete</a>
                    </td>
                </tr>";
            }

            $connection->close();
            ?>
        </tbody>
    </table>
</body>
</html> 