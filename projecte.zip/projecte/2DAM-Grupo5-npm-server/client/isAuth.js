var app = new Vue({
    el:"#app",
    vuetify: new Vuetify(),
    data: {
        response:{},
        datosUsu:{
        usuari: "",
        contrasenya: "",
        correo: "",
        rol:"",
        }
    },
    methods:{
        logout: function(){
            async function logouts() {
                console.log("Start logout")
                let url = 'logout';
                try {
                    let res = await fetch("http://127.0.0.1:3000/"+url,{
                        method: 'GET',
                        credentials: "include",
                        headers: {
                            'Accept': 'application/json',
                            'Content-Type': 'application/json'
                        },
                    });
                    return await res.text();
                } catch (error) {
                    console.log(error);
                }
            }
            
            async function tancar() {
                await logouts();
                window.location.href='index.html'
            }
            
            tancar()
        },
    },
    beforeCreate () {

        async function getAuth() {
            let url = 'isAuthenticated';
            try {
                let res = await fetch("http://127.0.0.1:3000/"+url,{
                    method: 'POST',
                    credentials: "include",
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                });
                return await res.text();
            } catch (error) {
                console.log(error);
            }
        }
        
        async function isAuth() {
            let authenticated = await getAuth();
            if(authenticated!="true"){
                window.location.href='menuUsu.html'
            }
        }

        isAuth();
    },
    

})