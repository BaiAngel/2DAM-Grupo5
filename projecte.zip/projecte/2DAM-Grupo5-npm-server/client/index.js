var app = new Vue({
    el:"#app",
    vuetify: new Vuetify(),
    data: {
        response:{},
        datosUsu:{
        usuari: "",
        contrasenya: "",
        correo: "",
        rol:"",
        }
    },
    methods:{
        crearUsuari: function(){
            console.log("Start crearUsuari")
            const myHeaders = new Headers()
            fetch("http://127.0.0.1:3000/signin",{
                method: 'POST',
                credentials: "include",
                headers: {
                  'Accept': 'application/json',
                  'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.datosUsu)
            }).then(
                (response)=>{
                    console.log(response)
                    return response.json()
                }
            ).then(
                (data)=>{
                    console.log(data)
                    this.response = data
                }
            ).catch(
                (error)=>{
                    console.log("ERROR!!")
                    console.log(error)
                }
            )
        },
        iniciarSessioUsername: function(){
            console.log("Start iniciarSessioUsername")
            const myHeaders = new Headers()
            fetch("http://127.0.0.1:3000/loginUsername",{
                method: 'POST',
                credentials: "include",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.datosUsu)
            }).catch(
                (error)=>{
                    console.log("ERROR!!")
                    console.log(error)
                }
        )
        },
        iniciarSessioUsernameGet: function(){
            console.log("Start iniciarSessioUsername")
            const myHeaders = new Headers()
            fetch("http://127.0.0.1:3000/auth/user/arnau/passwd/arnau1",{
                method: 'GET',
                credentials: "include",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify(this.datosUsu)
            }).catch(
                (error)=>{
                    console.log("ERROR!!")
                    console.log(error)
                }
        )
        },
        iniciarSessioCorreu: function(){
                console.log("Start iniciarSessioCorreu")
                const myHeaders = new Headers()
                let respon = fetch("http://127.0.0.1:3000/loginCorreu",{
                    method: 'POST',
                    credentials: "include",
                    headers: {
                        'Accept': 'application/json',
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify(this.datosUsu)
                }).catch(
                    (error)=>{
                        console.log("ERROR!!")
                        console.log(error)
                    }
                )
        },
    }
})