const express = require ("express")
const session = require("express-session")
const cors = require ("cors")
const mysql = require('mysql2');
const bodyParser = require("body-parser");

const app = express()
const PORT = 3000

var con = mysql.createConnection({
    host: "labs.inspedralbes.cat",
    user: "a19angavimar_User",
    password: "Projecto_grupo5",
    database: "a19angavimar_Usuarios"
})

app.use(session({
    secret:"1234",
    resave: true,
    saveUninitialized: true,
    cookie: {
      secure:false,
    },
}))

var auth = function(req, res, next) {
  if (req.session && req.session.user)
    return next();
  else
    return res.sendStatus(401);
};

app.use (cors({credentials: true, origin: true}))

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
  
  app.post('/isAuthenticated',auth, function (req, res) {
    res.send(true)
  })

  app.post("/loginUsername", (req, res) => {
    var user_name = req.body.usuari;
    var password = req.body.contrasenya;
    con.query('SELECT * FROM Users WHERE nom = "'+user_name+'" and pass = "'+password+'" LIMIT 1;', function (err, result, fields) {
        if (err) throw err;
        if (result != "") {
          req.session.user = result[0].nom
          req.session.admin = true;
          req.session.save()
          res.send(true)
        }
        else 
          res.send(false)
    });
})
//Per l'android
app.get('/auth/user/:userid/passwd/:passwdid', function (req, res) {
  let user_name = req.params.userid
    let password = req.params.passwdid
    con.query('SELECT * FROM Users WHERE nom = "'+user_name+'" and pass = "'+password+'" LIMIT 1;', function (err, result, fields) {
        if (err) throw err;
        console.log(result)
        res.send(result)
    });
})
app.get('/logout', function (req, res) {
  req.session.destroy();
  res.send("logout fet")
});

app.post("/signin", (req, res) => {
    var user_name = req.body.usuari;
    var password = req.body.contrasenya;
    var gmail = req.body.correo;
    con.query('insert into Users values (null,"'+user_name+'","'+password+'","'+gmail+'","usuari");',(err,result) =>{
        if (err) throw err;
    })
})

app.post("/loginCorreu", (req, res) => {
    var password = req.body.contrasenya;
    var gmail = req.body.correo;
    con.query('SELECT * FROM Users WHERE mail = "'+gmail+'" and pass = "'+password+'" LIMIT 1;', function (err, result, fields) {
      if (err) throw err;
        if (result != "") {
          req.session.user = result[0].nom
          req.session.admin = true;
          req.session.save()
          res.send(true)
        }
        else 
          res.send(false)
    });
})

app.listen(PORT, ()=>{
    console.log("SERVER RUNNING ["+PORT+"]")
})